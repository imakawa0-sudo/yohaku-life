# 余白の暮らし｜編集用SVG原画 26点

これは、以前Figmaの原画編集作業と合わせてGitHubに保存していた、48×56ドットの編集可能なSVGをまとめたZIPです。2026年11月22日時点の保存データを収録しています。

- svg/portraits/：顔・服を含む住民プロフィール9組×修正前後＝18枚。
- svg/clothing/：服装4組×体型維持の修正前後＝8枚。

これらは今回 Figma から再エクスポートした SVG ではなく、GitHubに保存済みの原画です。PNG画像一式は別の figma-artwork-2026-11-22.zip にあります。

Figmaファイル：https://www.figma.com/design/ZkiWmMUIs252PTKSAocTns

「new」は承認済み最終版とは限りません。oldを消さず、画像単位で管理してください。
